#!/usr/bin/env python3
import json,sys,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1]; E=[]
def load(p):
    try:return json.loads((R/p).read_text('utf-8'))
    except Exception as e:E.append(f'{p}: {e}'); return None
def sha(p): return hashlib.sha256((R/p).read_bytes()).hexdigest()

b=load('系统/写手积分榜.json')
if b:
    evs=b.get('events',[]); ws=b.get('writers',{})
    if set(ws)!={'A','B','C'}:E.append('积分榜必须且只能包含A/B/C')
    ordered=[]; seen=set()
    for v in evs:
        ch=v.get('chapter'); w=v.get('winner'); jp=v.get('judge_path'); pts=v.get('points')
        if not isinstance(ch,int) or not isinstance(w,str) or w not in ('A','B','C') or pts!=1:
            E.append('积分事件格式错误'); continue
        if ch in seen:E.append(f'积分事件章节重复 CH{ch:03d}'); continue
        seen.add(ch); ordered.append((ch,w))
        if not jp or not (R/jp).exists():E.append(f'CH{ch:03d} judge_path无效')
        else:
            if v.get('judge_sha256')!=sha(jp):E.append(f'CH{ch:03d} judge_sha256不一致')
            j=load(jp)
            if j and (j.get('status')!='SELECTED' or j.get('winner')!=w or j.get('chapter')!=ch):
                E.append(jp+': 与积分事件不一致')
    ordered.sort()
    n=len(ordered)
    wins={x:sum(1 for _,w in ordered if w==x) for x in 'ABC'}
    recent={x:sum(1 for _,w in ordered[-10:] if w==x) for x in 'ABC'}
    last={x:next((ch for ch,w in reversed(ordered) if w==x),None) for x in 'ABC'}
    best={x:0 for x in 'ABC'}; runw=None; runn=0
    for _,w in ordered:
        if w==runw:runn+=1
        else:runw=w;runn=1
        best[w]=max(best[w],runn)
    cur={x:0 for x in 'ABC'}
    if ordered:
        lw=ordered[-1][1]
        for _,w in reversed(ordered):
            if w==lw:cur[lw]+=1
            else:break
    for x in 'ABC':
        d=ws.get(x,{})
        rate=wins[x]/n if n else 0.0
        if d.get('score')!=wins[x] or d.get('wins')!=wins[x]:E.append(f'写手{x}积分不一致')
        if d.get('entries')!=n:E.append(f'写手{x}参赛次数不一致')
        try:
            if abs(float(d.get('win_rate',0))-rate)>0.0001:E.append(f'写手{x}胜率不一致')
        except Exception:E.append(f'写手{x}胜率非法')
        if d.get('recent_10_wins')!=recent[x]:E.append(f'写手{x}最近10章不一致')
        if d.get('current_streak')!=cur[x] or d.get('best_streak')!=best[x]:E.append(f'写手{x}连胜数据不一致')
        if d.get('last_win_chapter')!=last[x]:E.append(f'写手{x}last_win_chapter不一致')
    expected_last=ordered[-1][0] if ordered else 0
    if b.get('updated_after_chapter')!=expected_last:E.append('updated_after_chapter不一致')

    mdp=R/'系统/写手积分榜.md'
    if not mdp.exists():E.append('缺少系统/写手积分榜.md')
    else:
        md=mdp.read_text('utf-8')
        for x in 'ABC':
            d=ws.get(x,{})
            rate=float(d.get('win_rate',0))*100
            line=f"| 写手{x} | {d.get('score')} | {d.get('entries')} | {d.get('wins')} | {rate:.1f}% | {d.get('recent_10_wins')} | {d.get('current_streak')} | {d.get('best_streak')} |"
            if line not in md:E.append(f'写手{x}公开MD榜单未与JSON同步')

    # Every final resolved judge result should have exactly one score event.
    judge_files=list(R.glob('工作区/章节裁判/CH*/正式裁判结果*.json'))
    for p in judge_files:
        j=load(str(p.relative_to(R)).replace('\\','/'))
        if j and j.get('status')=='SELECTED':
            ch=j.get('chapter')
            if ch not in seen:E.append(f'CH{ch:03d}已有正式裁判结果但积分事件缺失')

for e in E:print('ERROR:',e)
if E:sys.exit(1)
print('Writer Scoreboard CI PASS')
