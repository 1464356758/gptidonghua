#!/usr/bin/env python3
import json,re,sys,hashlib,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
errors=[]; warnings=[]
def err(x): errors.append(x)
def warn(x): warnings.append(x)
def load(path):
    p=ROOT/path
    try:return json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: err(f'{path}: JSON错误 {e}'); return None
def sha(path): return hashlib.sha256((ROOT/path).read_bytes()).hexdigest()
def count(text):
    return len(re.findall(r'[\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]',text))+len(re.findall(r'[A-Za-z0-9]+',text))

db=load('数据库入口.json'); st=load('运行状态.json'); machine=load('系统/状态机.json')
if db and st and machine:
    s,e=db['chapter_range']['start'],db['chapter_range']['end']; ch=st.get('chapter')
    if not isinstance(ch,int) or not s<=ch<=e:err(f'当前章{ch}超范围{s}-{e}')
    if st.get('project_state') not in machine['states']:err('未知project_state:'+str(st.get('project_state')))
    if st.get('stage_state') not in machine['stage_states']:err('未知stage_state:'+str(st.get('stage_state')))
    if not isinstance(st.get('state_revision'),int) or st.get('state_revision')<1:err('state_revision非法')
    rr=st.get('chapter_revision_round')
    if not isinstance(rr,int) or not 0<=rr<=3:err('chapter_revision_round非法')

# Validate each LOCK body and the three current-SHA gates.
for cp in ROOT.glob('定稿/CH*/锁定凭证*.json'):
    rel=str(cp.relative_to(ROOT)).replace('\\','/'); c=load(rel)
    if not c:continue
    body=c.get('body_path')
    if not body or not (ROOT/body).exists():err(rel+':正文不存在');continue
    a=sha(body)
    if a!=c.get('body_sha256'):err(rel+':正文SHA不一致')
    wc=count((ROOT/body).read_text(encoding='utf-8'))
    if wc!=c.get('word_count'):err(rel+f":字数不一致 cert={c.get('word_count')} actual={wc}")
    if db:
        mn,mx=db['chapter_words']['min'],db['chapter_words']['max']
        if not mn<=wc<=mx:err(rel+f':字数{wc}超出{mn}-{mx}')
    for key,typ in [('logic_review_path','LOGIC'),('style_review_path','STYLE')]:
        rp=c.get(key)
        if not rp or not (ROOT/rp).exists():err(rel+':'+key+'缺失');continue
        rv=load(rp)
        if rv:
            if rv.get('review_type')!=typ:err(rp+':类型错误')
            if not rv.get('pass'):err(rp+':未通过')
            if rv.get('body_sha256')!=a:err(rp+':SHA不一致')
            if rv.get('fatal') or rv.get('major'):err(rp+':pass但仍有fatal/major')
            if typ=='STYLE' and (rv.get('score') is None or rv.get('score',0)<88):err(rp+':文风通过但分数<88')
    gp=c.get('commercial_gate_path')
    if not gp or not (ROOT/gp).exists():err(rel+':商业门禁缺失')
    else:
        g=load(gp)
        if g:
            if not g.get('pass'):err(gp+':未通过')
            if g.get('score',0)<85:err(gp+':低于85')
            if g.get('body_sha256')!=a:err(gp+':SHA不一致')
            if g.get('hard_failures'):err(gp+':pass但hard_failures非空')
            if len(g.get('value_events',[]))<2:err(gp+':价值事件<2')

# Enforce project/stage transition legality between consecutive commits.
try:
    prev=json.loads(subprocess.check_output(['git','show','HEAD^:运行状态.json'],cwd=ROOT,stderr=subprocess.DEVNULL).decode())
    if st and machine:
        a,b=prev.get('project_state'),st.get('project_state')
        if a!=b and b not in machine['allowed_transitions'].get(a,[]):err(f'非法project_state跳转 {a}->{b}')
        sa,sb=prev.get('stage_state','NOT_DUE'),st.get('stage_state','NOT_DUE')
        if sa!=sb and sb not in machine['stage_allowed_transitions'].get(sa,[]):err(f'非法stage_state跳转 {sa}->{sb}')
        if st.get('state_revision',0)<prev.get('state_revision',0):err('state_revision倒退')
except Exception:
    pass

patterns=[('与此同时',6),('值得注意的是',2),('在某种程度上',2),('这意味着',6),('他意识到',8),('她意识到',8)]
for p in list(ROOT.glob('稿件/**/正文.txt'))+list(ROOT.glob('定稿/CH*/LOCK-*.txt')):
    try:t=p.read_text(encoding='utf-8')
    except Exception:continue
    for phrase,limit in patterns:
        n=t.count(phrase)
        if n>limit:warn(f"{p.relative_to(ROOT)} '{phrase}'={n}")

for x in warnings:print('WARNING:',x)
for x in errors:print('ERROR:',x)
if errors:print(f'Novel CI FAIL: {len(errors)}');sys.exit(1)
print(f'Novel CI PASS warnings={len(warnings)}')
