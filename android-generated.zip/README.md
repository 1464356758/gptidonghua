# 第一部小说

AUTO-0.2.0-RC2｜三书全局六席接力系统。

小说仓库：https://github.com/sample/novel
分支：main
目标平台：番茄小说
章节：1—100
字数：8000—10000
学堂：https://github.com/mirror-owner/rules
学堂分支：rules/stable

先在控制台绑定本书独立十角色对话，选择题材后再进入正式生产。执行协议：自动化/角色执行协议.md。原五套CI保留。此包未经真实账号全流程验收，不能称为最终锁定版。
