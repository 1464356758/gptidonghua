#!/usr/bin/env python3
import json,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]; E=[]
def err(x): E.append(x)
def load(p,required=True):
    q=R/p
    if not q.exists():
        if required: err(f'{p}: 文件不存在')
        return None
    try:return json.loads(q.read_text('utf-8'))
    except Exception as e: err(f'{p}: JSON错误 {e}'); return None

db=load('数据库入口.json'); st=load('运行状态.json'); sm=load('系统/状态机.json')
sp=R/'设定/阶段结构.json'
if st and sm:
    ss=st.get('stage_state')
    if ss not in sm.get('stage_states',[]): err('stage_state非法')
if sp.exists():
    s=load('设定/阶段结构.json')
    if s:
        stages=s.get('stages',[])
        if not stages: err('阶段结构为空')
        seen=set(); prev=None
        cr=(db or {}).get('chapter_range',{})
        for i,x in enumerate(stages):
            sid=x.get('stage_id'); a=x.get('start_chapter'); b=x.get('end_chapter')
            for k in ('stage_id','start_chapter','end_chapter','stage_goal','reader_promise','mandatory_payoffs','entry_state','exit_state','status'):
                if k not in x: err(f'阶段#{i+1}缺字段 {k}')
            if sid in seen: err(f'阶段ID重复 {sid}')
            seen.add(sid)
            if not isinstance(a,int) or not isinstance(b,int) or a>b:
                err(f'{sid}: 章节范围非法'); continue
            if prev is not None and a!=prev+1: err(f'{sid}: 与上一阶段不连续')
            prev=b
        if stages and db:
            if stages[0].get('start_chapter')!=cr.get('start'): err('第一阶段未从配置起始章开始')
            if stages[-1].get('end_chapter')!=cr.get('end'): err('最后阶段未覆盖配置结束章')
else:
    active={'TASK_READY','WRITING','JUDGING','DUAL_REVIEW','REVISION','READY_TO_LOCK','LOCKED','COMPLETED'}
    if st and st.get('project_state') in active: err('正式生产开始后必须存在设定/阶段结构.json')

for e in E: print('ERROR:',e)
if E: sys.exit(1)
print('Stage CI PASS')
