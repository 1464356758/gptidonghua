#!/usr/bin/env python3
import json,sys,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1]; E=[]
def err(x): E.append(x)
def load(p,required=True):
    q=R/p
    if not q.exists():
        if required: err(f'{p}: 文件不存在')
        return None
    try:return json.loads(q.read_text('utf-8'))
    except Exception as e: err(f'{p}: JSON错误 {e}'); return None
def sha(p):
    return hashlib.sha256((R/p).read_bytes()).hexdigest()
def rel(p): return str(p.relative_to(R)).replace('\\','/')

db=load('数据库入口.json'); st=load('运行状态.json')
sp=R/'设定/阶段结构.json'
active={'TASK_READY','WRITING','JUDGING','DUAL_REVIEW','REVISION','READY_TO_LOCK','LOCKED','COMPLETED'}
if st and st.get('project_state') in active and not sp.exists():
    err('正式生产开始后必须存在设定/阶段结构.json')
s=load('设定/阶段结构.json',False) if sp.exists() else None

current_stage_locks={}
if s and db:
    stages=s.get('stages',[])
    cr=db.get('chapter_range',{})
    if not stages: err('阶段结构为空')
    else:
        if stages[0].get('start_chapter')!=cr.get('start'): err('第一阶段未从配置起始章开始')
        if stages[-1].get('end_chapter')!=cr.get('end'): err('最后阶段未覆盖配置结束章')
    seen_sid=set(); prev=None
    for x in stages:
        sid=x.get('stage_id'); a=x.get('start_chapter'); b=x.get('end_chapter'); status=x.get('status')
        if sid in seen_sid: err(f'{sid}: stage_id重复')
        seen_sid.add(sid)
        if not isinstance(a,int) or not isinstance(b,int) or a>b:
            err(f'{sid}: 范围非法'); continue
        if prev is not None and a!=prev+1: err(f'{sid}: 与上一阶段不连续')
        prev=b
        # prevent production from passing an unclosed prior stage
        ch=st.get('chapter') if st else None
        if isinstance(ch,int) and ch>b and status!='CLOSED':
            err(f'{sid}: 当前已进入后续章节但上一阶段未CLOSED')
        if status!='CLOSED':
            continue

        snap_p=f'工作区/阶段总审/{sid}/阶段快照.json'
        review_p=f'工作区/阶段总审/{sid}/阶段总审.json'
        lock_p=f'阶段锁定/{sid}/阶段LOCK.json'
        snap=load(snap_p); review=load(review_p); slock=load(lock_p)
        if not snap or not review or not slock: continue

        if snap.get('stage_id')!=sid or snap.get('start_chapter')!=a or snap.get('end_chapter')!=b:
            err(f'{sid}: 阶段快照范围/ID不一致')
        entries=snap.get('chapter_locks',[])
        chapters=[e.get('chapter') for e in entries if isinstance(e,dict)]
        expected=list(range(a,b+1))
        if chapters!=expected:
            err(f'{sid}: 阶段快照必须按顺序且唯一覆盖{a}-{b}，actual={chapters}')
        paths=[e.get('lock_path') for e in entries if isinstance(e,dict)]
        if len(paths)!=len(set(paths)): err(f'{sid}: 阶段快照存在重复LOCK路径')
        for e in entries:
            if not isinstance(e,dict): continue
            cp=e.get('lock_path'); chn=e.get('chapter')
            if not cp or not (R/cp).exists():
                err(f'{sid}: 缺章节LOCK凭证 {cp}'); continue
            actual_cert_sha=sha(cp)
            if actual_cert_sha!=e.get('lock_sha256'): err(f'{sid}: CH{chn:03d} LOCK凭证SHA已变化')
            cert=load(cp)
            if cert:
                if cert.get('chapter')!=chn or cert.get('status')!='LOCKED': err(f'{sid}: {cp}章节/status错误')
                if cert.get('body_sha256')!=e.get('body_sha256'): err(f'{sid}: CH{chn:03d}正文SHA与快照不一致')
                bp=cert.get('body_path')
                if not bp or not (R/bp).exists(): err(f'{sid}: CH{chn:03d}定稿正文不存在')
                elif sha(bp)!=cert.get('body_sha256'): err(f'{sid}: CH{chn:03d}定稿正文已变化')

        snap_sha=sha(snap_p)
        if review.get('review_type')!='STAGE' or review.get('stage_id')!=sid:
            err(f'{sid}: 阶段总审类型/ID错误')
        if not review.get('pass') or review.get('status')!='PASS': err(f'{sid}: 阶段总审未PASS')
        if review.get('snapshot_path')!=snap_p or review.get('snapshot_sha256')!=snap_sha:
            err(f'{sid}: 阶段总审没有绑定当前阶段快照')
        review_sha=sha(review_p)
        if slock.get('stage_id')!=sid or slock.get('status')!='STAGE_LOCKED':
            err(f'{sid}: 阶段LOCK格式错误')
        if slock.get('stage_snapshot_path')!=snap_p or slock.get('stage_snapshot_sha256')!=snap_sha:
            err(f'{sid}: 阶段LOCK未绑定当前快照')
        if slock.get('stage_review_path')!=review_p or slock.get('stage_review_sha256')!=review_sha:
            err(f'{sid}: 阶段LOCK未绑定当前总审报告')
        lock_paths=slock.get('chapter_lock_paths',[])
        if lock_paths!=paths: err(f'{sid}: 阶段LOCK章节列表必须与快照完全一致')
        if len(lock_paths)!=len(set(lock_paths)): err(f'{sid}: 阶段LOCK章节路径重复')
        current_stage_locks[sid]=(lock_p,sha(lock_p))

# Completion must bind FINAL review to exact current stage-lock set.
if st and st.get('project_state')=='COMPLETED':
    if st.get('stage_state')!='FINAL_CLOSED': err('COMPLETED要求stage_state=FINAL_CLOSED')
    if s:
        closed=[x for x in s.get('stages',[]) if x.get('status')=='CLOSED']
        if len(closed)!=len(s.get('stages',[])): err('COMPLETED但存在未CLOSED阶段')
    book_p='工作区/阶段总审/FINAL/全书快照.json'
    final_p='工作区/阶段总审/FINAL/全书终审.json'
    book=load(book_p); final=load(final_p)
    if book and final:
        if book.get('status')!='BOOK_SNAPSHOT_READY': err('全书快照status错误')
        bes=book.get('stage_locks',[])
        ids=[e.get('stage_id') for e in bes if isinstance(e,dict)]
        expected_ids=[x.get('stage_id') for x in (s or {}).get('stages',[])]
        if ids!=expected_ids: err('全书快照未按阶段结构完整覆盖全部阶段')
        if len(ids)!=len(set(ids)): err('全书快照阶段ID重复')
        current_map={}
        for e in bes:
            if not isinstance(e,dict): continue
            sid=e.get('stage_id'); lp=e.get('stage_lock_path')
            if not lp or not (R/lp).exists(): err(f'全书快照缺阶段LOCK {lp}'); continue
            a=sha(lp); current_map[sid]=a
            if e.get('stage_lock_sha256')!=a: err(f'{sid}: 全书快照绑定的阶段LOCK已过期')
        book_sha=sha(book_p)
        if final.get('review_type')!='FINAL_BOOK' or not final.get('pass') or final.get('status')!='PASS':
            err('全书终审未PASS')
        if final.get('snapshot_path')!=book_p or final.get('snapshot_sha256')!=book_sha:
            err('全书终审未绑定当前全书快照')
        if final.get('stage_lock_sha256s')!=current_map:
            err('全书终审绑定的阶段LOCK集合不是当前版本')

for e in E: print('ERROR:',e)
if E: sys.exit(1)
print('Strict Stage CI PASS')
