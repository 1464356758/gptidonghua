#!/usr/bin/env python3
import json,sys,re,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1]; E=[]; W=[]
SHA64=re.compile(r'^[0-9a-f]{64}$'); SHA40=re.compile(r'^[0-9a-f]{40}$')
def err(x):E.append(x)
def warn(x):W.append(x)
def load(p,required=True):
    q=R/p
    if not q.exists():
        if required:err(f'{p}: 文件不存在')
        return None
    try:return json.loads(q.read_text('utf-8'))
    except Exception as e:err(f'{p}: JSON错误 {e}');return None
def sha(p):return hashlib.sha256((R/p).read_bytes()).hexdigest()
def exists(p):return bool(p) and (R/p).exists()
def body_count(text):
    return len(re.findall(r'[\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]',text))+len(re.findall(r'[A-Za-z0-9]+',text))

db=load('数据库入口.json'); st=load('运行状态.json'); sm=load('系统/状态机.json')

# Static contract: all roles must explicitly carry read and routing markers.
roles=[
'角色指令/01_灵感员.txt','角色指令/02_灵感裁判.txt','角色指令/03_总监.txt','角色指令/04_写手A.txt',
'角色指令/05_写手B.txt','角色指令/06_写手C.txt','角色指令/07_章节裁判.txt','角色指令/08_逻辑审核员.txt',
'角色指令/09_中文文风审核员.txt','角色指令/10_阶段总审员.txt']
for p in roles:
    q=R/p
    if not q.exists():err(p+': 缺失');continue
    t=q.read_text('utf-8')
    if '【下一步｜必须照做】' not in t:err(p+': 缺下一步尾注')
    if '【开工前必读】' not in t and '初始化ZIP模式' not in t:err(p+': 缺明确必读段')
if not (R/'系统/人工路由与回复尾注协议.md').exists():err('缺人工路由协议')
if not (R/'系统/角色必读与交接矩阵.md').exists():err('缺角色必读矩阵')

if st and sm:
    if st.get('project_state') not in sm.get('states',[]):err('运行状态project_state非法')
    if st.get('stage_state') not in sm.get('stage_states',[]):err('运行状态stage_state非法')
    ns=st.get('next_step',{})
    if ns.get('mode') not in ('SINGLE','PARALLEL','USER_ACTION','STAY','DONE'):err('next_step.mode非法')
    if not isinstance(ns.get('roles'),list) or not isinstance(ns.get('instruction'),str):err('next_step格式非法')
    rr=st.get('chapter_revision_round')
    if not isinstance(rr,int) or not 0<=rr<=3:err('chapter_revision_round非法')

# State prerequisite order. State is updated LAST, so reaching a state means prerequisites must already exist.
order=['WAIT_IDEA','IDEAS_READY','IDEA_REVIEWED','USER_SELECTED','PROJECT_SETUP','TASK_READY','WRITING','JUDGING','DUAL_REVIEW','REVISION','READY_TO_LOCK','LOCKED','COMPLETED']
rank={x:i for i,x in enumerate(order)}
ps=st.get('project_state') if st else None
def at_least(name):return ps in rank and rank[ps]>=rank[name]
if st:
    if at_least('IDEAS_READY') and not exists(st.get('idea_delivery_path')):err('IDEAS_READY后idea_delivery_path必须存在')
    if at_least('IDEA_REVIEWED') and not exists(st.get('idea_review_path')):err('IDEA_REVIEWED后idea_review_path必须存在')
    if at_least('USER_SELECTED') and not exists(st.get('user_selection_path')):err('USER_SELECTED后user_selection_path必须存在')
    if at_least('PROJECT_SETUP'):
        if not (R/'设定/阶段结构.json').exists():err('PROJECT_SETUP后缺设定/阶段结构.json')
        snap=load('设定/平台规则快照.json',False)
        if not snap:err('PROJECT_SETUP后缺有效平台规则快照')
        elif not SHA40.match(str(snap.get('academy_commit_sha',''))):err('平台规则快照academy_commit_sha非法')
    if ps in ('TASK_READY','WRITING','JUDGING','DUAL_REVIEW','REVISION','READY_TO_LOCK'):
        if not exists(st.get('current_task_path')):err('当前生产状态缺current_task_path')
        if not exists(st.get('context_package_path')):err('当前生产状态缺context_package_path')

# Validate current TASK and context.
if st and exists(st.get('current_task_path')):
    tp=st['current_task_path']; t=load(tp)
    if t:
        if t.get('task_id')!=st.get('task_id') or t.get('chapter')!=st.get('chapter'):err(tp+': 与运行状态task/chapter不一致')
        if db and t.get('platform')!=db.get('platform'):err(tp+': platform与数据库入口不一致')
        wr=t.get('body_word_range',{})
        if db and (wr.get('min')!=db['chapter_words']['min'] or wr.get('max')!=db['chapter_words']['max']):err(tp+': 字数范围不一致')
        ch=t.get('chapter')
        if db and ch and ch>db['chapter_range']['start']:
            pp=t.get('previous_lock_path'); ph=t.get('previous_lock_sha256')
            if not exists(pp):err(tp+': 非首章previous_lock_path无效')
            elif sha(pp)!=ph:err(tp+': previous_lock_sha256不一致')
        if t.get('academy_snapshot_path')!='设定/平台规则快照.json':err(tp+': academy_snapshot_path必须指向冻结快照')
if st and exists(st.get('context_package_path')):
    cp=st['context_package_path']; c=load(cp)
    if c and (c.get('task_id')!=st.get('task_id') or c.get('chapter')!=st.get('chapter')):err(cp+': 与运行状态不一致')

# Scan every writer delivery.
for p in R.glob('稿件/第*章/写手*/V*/交付.json'):
    rel=str(p.relative_to(R)).replace('\\','/'); d=load(rel)
    if not d:continue
    bp=d.get('body_path')
    if not exists(bp):err(rel+': body_path无效');continue
    if sha(bp)!=d.get('body_sha256'):err(rel+': body_sha256不一致')
    if body_count((R/bp).read_text('utf-8'))!=d.get('word_count'):err(rel+': word_count不一致')
    if d.get('writer') not in ('A','B','C'):err(rel+': writer非法')
    if not isinstance(d.get('self_strategy'),str) or len(d.get('self_strategy',''))>120:err(rel+': self_strategy非法')

# Blind package/result/resolution.
if st and ps=='JUDGING' and not exists(st.get('blind_package_path')):err('JUDGING缺blind_package_path')
if st and exists(st.get('blind_package_path')):
    bp=st['blind_package_path']; b=load(bp)
    if b:
        cans=b.get('candidates',{})
        if set(cans)!={'X','Y','Z'}:err(bp+': candidates必须X/Y/Z')
        shas=[]
        for a in ('X','Y','Z'):
            x=cans.get(a,{})
            if not exists(x.get('body_path')):err(bp+f': {a}正文不存在')
            elif sha(x['body_path'])!=x.get('body_sha256'):err(bp+f': {a} SHA不一致')
            shas.append(x.get('body_sha256'))
        if len(set(shas))<3:err(bp+': 三份匿名稿出现相同SHA，竞争无效')

if st and exists(st.get('blind_result_path')):
    rp=st['blind_result_path']; r=load(rp)
    bp=load(st.get('blind_package_path'),False) if exists(st.get('blind_package_path')) else None
    if r:
        wa=r.get('winner_alias')
        if wa not in ('X','Y','Z'):err(rp+': winner_alias非法')
        for a,x in r.get('candidates',{}).items():
            dims=['task_fit','causal','character','attraction_pacing','chinese_naturalness','commercial_value','originality_completion']
            if any(not isinstance(x.get(k),int) for k in dims):err(rp+f': {a}维度分缺失')
            else:
                total=sum(x[k] for k in dims)
                if total!=x.get('total'):err(rp+f': {a} total不等于7维之和')
        if bp and wa in bp.get('candidates',{}) and r.get('winner_body_sha256')!=bp['candidates'][wa].get('body_sha256'):err(rp+': winner SHA与匿名包不一致')

if st and exists(st.get('resolved_judge_path')):
    jp=st['resolved_judge_path']; j=load(jp)
    if j:
        br=j.get('blind_result_path'); mp=j.get('mapping_path')
        if not exists(br) or sha(br)!=j.get('blind_result_sha256'):err(jp+': 盲评结果引用/SHA错误')
        if not exists(mp) or sha(mp)!=j.get('mapping_sha256'):err(jp+': 映射引用/SHA错误')
        rr=load(br,False) if exists(br) else None; mm=load(mp,False) if exists(mp) else None
        if rr and mm:
            alias=rr.get('winner_alias'); writer=mm.get('mapping',{}).get(alias)
            if j.get('winner_alias')!=alias or j.get('winner')!=writer:err(jp+': 解封winner与盲评/映射不一致')
            if j.get('winner_body_sha256')!=rr.get('winner_body_sha256'):err(jp+': winner正文SHA不一致')
            # resolved scores must be exact alias->writer totals
            for a,w in mm.get('mapping',{}).items():
                if a in rr.get('candidates',{}) and j.get('scores',{}).get(w)!=rr['candidates'][a].get('total'):err(jp+f': 写手{w}分数解映射错误')

# READY_TO_LOCK requires all current SHA checks and memory application.
if st and ps in ('READY_TO_LOCK','LOCKED'):
    target=st.get('candidate_body_path'); target_sha=st.get('candidate_body_sha256')
    if not exists(target):err('待LOCK正文不存在')
    elif sha(target)!=target_sha:err('待LOCK正文SHA与运行状态不一致')
    for key,typ in [('logic_review_path','LOGIC'),('style_review_path','STYLE')]:
        rp=st.get(key)
        if not exists(rp):err(key+'缺失');continue
        rv=load(rp)
        if rv:
            if rv.get('body_sha256')!=target_sha or rv.get('review_type')!=typ or not rv.get('pass'):err(rp+': 未对当前SHA通过')
            if rv.get('fatal') or rv.get('major'):err(rp+': pass但fatal/major非空')
            if typ=='STYLE' and (rv.get('score') is None or rv.get('score',0)<88):err(rp+': STYLE通过分数不足')
    gp=st.get('commercial_gate_path')
    if not exists(gp):err('commercial_gate_path缺失')
    else:
        g=load(gp)
        if g and (g.get('body_sha256')!=target_sha or not g.get('pass') or g.get('score',0)<85 or g.get('hard_failures')):err(gp+': 商业门禁未对当前SHA有效通过')
    dp=st.get('memory_delta_path'); mr=st.get('memory_apply_receipt_path')
    if not exists(dp):err('memory_delta_path缺失')
    else:
        d=load(dp)
        if d:
            if d.get('body_sha256')!=target_sha:err(dp+': 记忆增量SHA不一致')
            n=len(d.get('summary',''))
            if not 300<=n<=500:err(dp+f': 摘要长度{n}不在300-500')
    if not exists(mr):err('memory_apply_receipt_path缺失')
    else:
        m=load(mr)
        if m:
            if m.get('body_sha256')!=target_sha:err(mr+': 回执正文SHA不一致')
            if not exists(m.get('delta_path')) or sha(m['delta_path'])!=m.get('delta_sha256'):err(mr+': delta引用/SHA错误')
            for lp,lh in m.get('updated_ledgers',{}).items():
                if not exists(lp) or sha(lp)!=lh:err(mr+f': 记忆账本未按回执落盘 {lp}')

# Revision lineage if revisions occurred.
if st and isinstance(st.get('chapter_revision_round'),int) and st.get('chapter_revision_round',0)>0 and ps in ('READY_TO_LOCK','LOCKED'):
    lp=st.get('revision_lineage_path')
    if not exists(lp):err('有返修但缺revision_lineage_path')
    else:
        l=load(lp)
        if l:
            versions=l.get('versions',[])
            if l.get('round_count')!=len(versions):err(lp+': round_count不一致')
            prev=l.get('selection_body_sha256')
            for i,v in enumerate(versions,1):
                if v.get('round')!=i or v.get('source_sha256')!=prev:err(lp+f': 第{i}轮版本链断裂')
                if not exists(v.get('output_path')) or sha(v['output_path'])!=v.get('output_sha256'):err(lp+f': 第{i}轮output无效')
                prev=v.get('output_sha256')
            if l.get('final_body_sha256')!=prev or l.get('final_body_sha256')!=st.get('candidate_body_sha256'):err(lp+': final SHA与当前正文不一致')

# LOCK certificate.
if st and ps=='LOCKED':
    lp=st.get('lock_certificate_path')
    if not exists(lp):err('LOCKED但lock_certificate_path无效')
    else:
        c=load(lp)
        if c:
            if c.get('body_sha256')!=st.get('candidate_body_sha256'):err(lp+': lock SHA与运行状态不一致')
            sj=c.get('selection_judge_path')
            if not exists(sj):err(lp+': selection_judge_path无效')
            else:
                j=load(sj)
                if j and (j.get('winner')!=c.get('writer') or j.get('winner_body_sha256')!=c.get('selection_body_sha256')):err(lp+': selection lineage与正式裁判不一致')

# Publication cannot outrun continuous LOCKs.
pub=load('运营/发布状态.json',False)
if pub and db:
    pt=pub.get('published_through_chapter',0)
    if not isinstance(pt,int) or pt<0:err('发布状态published_through_chapter非法')
    if pt:
        for ch in range(db['chapter_range']['start'],pt+1):
            matches=list(R.glob(f'定稿/CH{ch:03d}/锁定凭证*.json'))
            if not matches:err(f'发布线到CH{pt:03d}但CH{ch:03d}无LOCK凭证')

for w in W:print('WARNING:',w)
for e in E:print('ERROR:',e)
if E:sys.exit(1)
print(f'Contract CI PASS warnings={len(W)}')
